package mob.mobgcm;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.json.JSONException;
import org.json.JSONObject;

public class FCMSMessageServer {

	public static void main(String[] args) {

		FCMSMessageServer fcm = new FCMSMessageServer();
		fcm.send();
	}
	
	public void send() {

		// COLOQUE AQUI SUA CHAVE
		String API_KEY = "AIzaSyBifphIDyyL6nJ0lgtttd9_MhqTw1KUsM0";


		try {
			JSONObject jGcmData = new JSONObject();
			JSONObject jData = new JSONObject();
			jData.put("message", "mensagem do servidor");

			jGcmData.put("to", "/topics/global");
			jGcmData.put("data", jData);

			URL url = new URL("https://android.googleapis.com/gcm/send");
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestProperty("Authorization", "key=" + API_KEY);
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestMethod("POST");
			conn.setDoOutput(true);

			// Send GCM message content.
			OutputStream outputStream = conn.getOutputStream();
			outputStream.write(jGcmData.toString().getBytes());

			// Read GCM response.
			InputStream inputStream = conn.getInputStream();
			String resp = convert(inputStream);
			System.out.println(resp);
			System.out.println("Check your device/emulator for notification or logcat for " +
					"confirmation of the receipt of the GCM message.");
			
		} catch (IOException | JSONException e) {
			System.out.println("Unable to send GCM message.");
			System.out.println("Please ensure that API_KEY has been replaced by the server " +
					"API key, and that the device's registration token is correct (if specified).");
			e.printStackTrace();
		}
	}


	public String convert(InputStream is) throws IOException {

		int ch;
		StringBuilder sb = new StringBuilder();
		while((ch = is.read()) != -1)
			sb.append((char)ch);

		return sb.toString();

	}

}
